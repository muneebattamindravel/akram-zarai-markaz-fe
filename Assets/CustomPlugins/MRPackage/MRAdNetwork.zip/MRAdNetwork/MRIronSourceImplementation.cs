﻿using UnityEngine.UI;
using UnityEngine;

public class MRIronSourceImplementation : BasicAdNetwork
{
    public string appKeyAndroid, appKeyIOS;
    string appKey;

    bool interstitialRequested = false;
    bool interstitialLoaded = false;
    bool videoRequested = false;
    bool videoLoaded = false;
    bool isRewardCompleted = false;

    public IronSourceBannerPosition bannerPosition;

    public override void InitializeAdNetwork()
    {
#if UNITY_ANDROID
        appKey = appKeyAndroid;
#endif
#if UNITY_IOS
        appKey = appKeyIOS;
#endif

        //GameObject.Find("MRLOG").GetComponent<Text>().text += "-In Initialize of the File-";
        //IronSource.Agent.setConsent(true);
        //GameObject.Find("MRLOG").GetComponent<Text>().text += "-Pass1-";
        IronSource.Agent.init(appKey);
        //GameObject.Find("MRLOG").GetComponent<Text>().text += "-Pass2-";
        IronSource.Agent.validateIntegration();
        //GameObject.Find("MRLOG").GetComponent<Text>().text += "-Pass3-";

        //GameObject.Find("MRLOG").GetComponent<Text>().text += "Iron Source Initialized";
    }

    void OnApplicationPause(bool isPaused)
    {
        IronSource.Agent.onApplicationPause(isPaused);
    }

    public override void RequestBanner()
    {
        if (MRGame.Instance.showAds)
        {
            //GameObject.Find("MRLOG").GetComponent<Text>().text += "Iron Source Banner Requested";
            IronSource.Agent.loadBanner(IronSourceBannerSize.SMART, bannerPosition);
        }
    }

    public override void DestroyBanner()
    {
        IronSource.Agent.destroyBanner();
    }

    void OnEnable()
    {
        IronSourceEvents.onInterstitialAdReadyEvent += InterstitialAdReadyEvent;
        IronSourceEvents.onInterstitialAdLoadFailedEvent += InterstitialAdLoadFailedEvent;
        IronSourceEvents.onInterstitialAdShowSucceededEvent += InterstitialAdShowSucceededEvent;
        IronSourceEvents.onInterstitialAdShowFailedEvent += InterstitialAdShowFailedEvent;
        IronSourceEvents.onInterstitialAdClickedEvent += InterstitialAdClickedEvent;
        IronSourceEvents.onInterstitialAdOpenedEvent += InterstitialAdOpenedEvent;
        IronSourceEvents.onInterstitialAdClosedEvent += InterstitialAdClosedEvent;

        IronSourceEvents.onRewardedVideoAdOpenedEvent += RewardedVideoAdOpenedEvent;
        IronSourceEvents.onRewardedVideoAdClosedEvent += RewardedVideoAdClosedEvent;
        IronSourceEvents.onRewardedVideoAvailabilityChangedEvent += RewardedVideoAvailabilityChangedEvent;
        IronSourceEvents.onRewardedVideoAdStartedEvent += RewardedVideoAdStartedEvent;
        IronSourceEvents.onRewardedVideoAdEndedEvent += RewardedVideoAdEndedEvent;
        IronSourceEvents.onRewardedVideoAdRewardedEvent += RewardedVideoAdRewardedEvent;
        IronSourceEvents.onRewardedVideoAdShowFailedEvent += RewardedVideoAdShowFailedEvent;
    }

    //Invoked when the initialization process has failed.
    //@param description - string - contains information about the failure.
    void InterstitialAdLoadFailedEvent(IronSourceError error)
    {
        //GameObject.Find("MRLOG").GetComponent<Text>().text += "Interstitial Load Failed";
        interstitialRequested = false;
        interstitialLoaded = false;
        GetComponent<MRUtilities>().InterstitialLoadFailed(this);
    }
    //Invoked right before the Interstitial screen is about to open.
    void InterstitialAdShowSucceededEvent()
    {
    }
    //Invoked when the ad fails to show.
    //@param description - string - contains information about the failure.
    void InterstitialAdShowFailedEvent(IronSourceError error)
    {
        //GameObject.Find("MRLOG").GetComponent<Text>().text += "Iron Source Int Failed: "+error.ToString();
    }
    // Invoked when end user clicked on the interstitial ad
    void InterstitialAdClickedEvent()
    {
    }
    //Invoked when the interstitial ad closed and the user goes back to the application screen.
    void InterstitialAdClosedEvent()
    {
        interstitialRequested = false;
        interstitialLoaded = false;

        GetComponent<MRUtilities>().InterstitialCompleted();
    }
    //Invoked when the Interstitial is Ready to shown after load function is called
    void InterstitialAdReadyEvent()
    {
        //GameObject.Find("MRLOG").GetComponent<Text>().text += "Iron Source Int Loaded";
        interstitialRequested = false;
        interstitialLoaded = true;

        GetComponent<MRUtilities>().InterstitialLoadSuccess(this);
    }
    //Invoked when the Interstitial Ad Unit has opened
    void InterstitialAdOpenedEvent()
    {
    }

    public override void RequestInterstitial()
    {
        if (!interstitialRequested)
        {
            IronSource.Agent.loadInterstitial();

            interstitialRequested = true;
            interstitialLoaded = false;

            //GameObject.Find("MRLOG").GetComponent<Text>().text += "Interstitial Requested";
        }
    }

    public override void ShowInterstitialAd()
    {
        //GameObject.Find("MRLOG").GetComponent<Text>().text = "Showing Int";
        IronSource.Agent.showInterstitial();

        interstitialRequested = false;
        interstitialLoaded = false;
    }

    //Invoked when the RewardedVideo ad view has opened.
    //Your Activity will lose focus. Please avoid performing heavy 
    //tasks till the video ad will be closed.
    void RewardedVideoAdOpenedEvent()
    {
        this.isRewardCompleted = false;
    }
    //Invoked when the RewardedVideo ad view is about to be closed.
    //Your activity will now regain its focus.
    void RewardedVideoAdClosedEvent()
    {
        if (this.isRewardCompleted)
            GetComponent<MRUtilities>().VideoAdCompleted(this);

        this.isRewardCompleted = false;
    }
    //Invoked when there is a change in the ad availability status.
    //@param - available - value will change to true when rewarded videos are available. 
    //You can then show the video by calling showRewardedVideo().
    //Value will change to false when no videos are available.
    void RewardedVideoAvailabilityChangedEvent(bool available)
    {
        //Change the in-app 'Traffic Driver' state according to availability.
        bool rewardedVideoAvailability = available;
        if (available)
        {
            videoRequested = false;
            videoLoaded = true;
            GetComponent<MRUtilities>().VideoAdLoadSuccess(this);
            //GameObject.Find("MRLOG").GetComponent<Text>().text += "Video Available";
        }
        else
        {
            videoRequested = false;
            videoLoaded = false;
            GetComponent<MRUtilities>().VideoAdLoadFailed(this);
            //GameObject.Find("MRLOG").GetComponent<Text>().text += "Video Load Failed";
        }
    }
    //  Note: the events below are not available for all supported rewarded video 
    //   ad networks. Check which events are available per ad network you choose 
    //   to include in your build.
    //   We recommend only using events which register to ALL ad networks you 
    //   include in your build.
    //Invoked when the video ad starts playing.
    void RewardedVideoAdStartedEvent()
    {
    }
    //Invoked when the video ad finishes playing.
    void RewardedVideoAdEndedEvent()
    {
    }
    //Invoked when the user completed the video and should be rewarded. 
    //If using server-to-server callbacks you may ignore this events and wait for the callback from the  ironSource server.
    //
    //@param - placement - placement object which contains the reward data
    //
    void RewardedVideoAdRewardedEvent(IronSourcePlacement placement)
    {
        this.isRewardCompleted = true;
    }
    //Invoked when the Rewarded Video failed to show
    //@param description - string - contains information about the failure.
    void RewardedVideoAdShowFailedEvent(IronSourceError error)
    {
    }

    public override void RequestVideoAd()
    {
        if (!videoRequested)
        {
            videoRequested = true;
            videoLoaded = false;
        }
    }

    public override void ShowVideoAd()
    {
        IronSource.Agent.showRewardedVideo();

        videoRequested = false;
        videoLoaded = false;
    }


    public override bool IsInterstitialRequested()
    {
        return interstitialRequested;
    }

    public override bool IsInterstitialLoaded()
    {
        return interstitialLoaded;
    }

    public override bool IsVideoAdRequested()
    {
        return videoRequested;
    }

    public override bool IsVideoAdLoaded()
    {
        return videoLoaded;
    }
}
