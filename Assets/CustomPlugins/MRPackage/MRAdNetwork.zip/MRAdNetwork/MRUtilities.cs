﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public enum AppOrientation {portrait, landscape};
public class MRUtilities : MonoBehaviour
{
    bool ENABLE_EDITOR_TESTING = false;
    List<BasicAdNetwork> interstitialImplementsPrioritized = null;
    List<BasicAdNetwork> interstitialQueue = new List<BasicAdNetwork>();

    List<BasicAdNetwork> videoAdImplementsPrioritized = null;
    List<BasicAdNetwork> videoAdQueue = new List<BasicAdNetwork>();

    GameObject mrPreLoaderCanvas;
    [HideInInspector]

    int INTERSTITIALRATE = 1;
    //int INTERSTITALCOUNTER = 0;
    int RATERATE = 10;
    int RATECOUNTER = 0;

    BasicAdNetwork BANNERNETWORK = null;
    bool ADNETWORKSTARTED = false;

    [HideInInspector]
    public static MRUtilities Instance = null;

    float timeInterstitialShown = 0f;

    void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
        if (GameObject.FindObjectsOfType<MRUtilities>().Length > 1)
        {
            Destroy(this.gameObject);
            return;
        }

        if (!Instance)
            Instance = this;

		StartCoroutine(InitializeMRUtilitiesHeavyFunctions());

    }

    private void OnHideUnity(bool isGameShown)
    {
        if (!isGameShown)
        {
            // Pause the game - we will need to hide
            Time.timeScale = 0;
        }
        else
        {
            // Resume the game - we're getting focus again
            Time.timeScale = 1;
        }
    }

    IEnumerator InitializeMRUtilitiesHeavyFunctions(bool p_wait = true)
    {
        if (p_wait)
            yield return new WaitForSeconds(1f);

		if (transform.Find("MRPreLoaderCanvas"))
		{
			mrPreLoaderCanvas = transform.Find("MRPreLoaderCanvas").gameObject;
			mrPreLoaderCanvas.SetActive(false);
		}

		StartCoroutine(StartAdNetworkAfterDelay());
	}

	public void ShowPreLoader() {
		if (mrPreLoaderCanvas)
			mrPreLoaderCanvas.SetActive(true);
	}

	public void HidePreLoader() {
		if (mrPreLoaderCanvas)
			mrPreLoaderCanvas.SetActive(false);
	}

	IEnumerator StartAdNetworkAfterDelay()
	{
		yield return new WaitForSeconds(1f);

		if (!ADNETWORKSTARTED)
		{
			StartAdNetwork("ADNETWORK INITIALIZED FROM TIME EXPIRATION");
		}
	}

	void StartAdNetwork(string str)
	{
		//GameObject.Find("MRLOG").GetComponent<Text>().text += str;

		if (ADNETWORKSTARTED)
			return;

        if (BANNERNETWORK == null) {
            //default
            BANNERNETWORK = GetComponent<MRIronSourceImplementation>();
        }

        if (interstitialImplementsPrioritized == null)
		{
			//Load Default
			interstitialImplementsPrioritized = new List<BasicAdNetwork>();
            //interstitialImplementsPrioritized.Add(GetComponent<MRUnityAdsImplementation>());
            interstitialImplementsPrioritized.Add(GetComponent<MRIronSourceImplementation>());
        }

        if (videoAdImplementsPrioritized == null)
		{
            //Load Default
            videoAdImplementsPrioritized = new List<BasicAdNetwork>();
            //videoAdImplementsPrioritized.Add(GetComponent<MRUnityAdsImplementation>());
            videoAdImplementsPrioritized.Add(GetComponent<MRIronSourceImplementation>());
        }

		//GameObject.Find("MRLOG").GetComponent<Text>().text += "Implements Initialized";

		//At this point we have the interstitial implements and the video implements (Either default or network loaded). See which networks to initialize.
		List<BasicAdNetwork> adNetworksToInitialize = new List<BasicAdNetwork>();
		if (BANNERNETWORK != null) {
			if (adNetworksToInitialize.Find(asd => asd.GetType() == BANNERNETWORK.GetType()) == null)
				adNetworksToInitialize.Add(BANNERNETWORK);
		}
		else
        {
			//GameObject.Find("MRLOG").GetComponent<Text>().text += "Banner Network is null";
		}
        for (int i = 0; i < interstitialImplementsPrioritized.Count; i++)
        {
            if (adNetworksToInitialize.Find(asd => asd.GetType() == interstitialImplementsPrioritized[i].GetType()) == null)
                adNetworksToInitialize.Add(interstitialImplementsPrioritized[i]);
        }
        for (int i = 0; i < videoAdImplementsPrioritized.Count; i++)
        {
            if (adNetworksToInitialize.Find(asd => asd.GetType() == videoAdImplementsPrioritized[i].GetType()) == null)
                adNetworksToInitialize.Add(videoAdImplementsPrioritized[i]);
        }

		//GameObject.Find("MRLOG").GetComponent<Text>().text += "Count To = "+adNetworksToInitialize.Count;
		for (int i = 0; i < adNetworksToInitialize.Count; i++)
        {
			//GameObject.Find("MRLOG").GetComponent<Text>().text += "-Initializing Now";
			adNetworksToInitialize[i].InitializeAdNetwork();
			//GameObject.Find("MRLOG").GetComponent<Text>().text += "-Pass1-";
		}

		//GameObject.Find("MRLOG").GetComponent<Text>().text += "-Pass2-";

		//GameObject.Find("MRLOG").GetComponent<Text>().text += "Show Ads? = "+MRGame.Instance.showAds;
		if (MRGame.Instance.showAds)
        {
            if (BANNERNETWORK != null)
            {
				//GameObject.Find("MRLOG").GetComponent<Text>().text += "Requesting Banner";
				BANNERNETWORK.RequestBanner();
			}
                
            RequestTopPriorityInterstitial();
        }

        RequestTopPriorityVideoAd();
		ADNETWORKSTARTED = true;
	}

	public void DestroyBannerAd()
	{
		if (BANNERNETWORK != null)
			BANNERNETWORK.DestroyBanner();
	}

	public void InterstitialLoadFailed(BasicAdNetwork p_adNetworkImplement)
	{
		int failedNetworkIndex = interstitialImplementsPrioritized.FindIndex(asd => asd.GetType() == p_adNetworkImplement.GetType());
		for (int i = failedNetworkIndex + 1; i < interstitialImplementsPrioritized.Count; i++)
		{
			if (!interstitialImplementsPrioritized[i].IsInterstitialRequested() && !interstitialImplementsPrioritized[i].IsInterstitialLoaded())
			{
				interstitialImplementsPrioritized[i].RequestInterstitial();
				break;
			}
		}
	}

	public void InterstitialLoadSuccess(BasicAdNetwork p_adNetworkImplement)
	{
        if (interstitialImplementsPrioritized.Find(asd => asd.GetType() == p_adNetworkImplement.GetType()) != null)
        {
            if (interstitialImplementsPrioritized[0].GetType() == p_adNetworkImplement.GetType())
                interstitialQueue.Insert(0, p_adNetworkImplement);
            else
                interstitialQueue.Add(p_adNetworkImplement);
        }

        RequestTopPriorityInterstitial();
	}

    public void InterstitialCompleted()
    {
        RequestTopPriorityInterstitial();

        if (interstitialAdCompleteAction != null)
            interstitialAdCompleteAction.Invoke();
    }

    public void ShowInterstitialAd(bool p_rateContolled = true,InterstitialAdAction p_interstitialAdCompleteAction = null)
	{
        if (p_interstitialAdCompleteAction == null) {
            if (!MRGame.Instance.showAds)
                return;
        }

        interstitialAdCompleteAction = p_interstitialAdCompleteAction;

		if (interstitialQueue.Count == 0)
		{
			RequestTopPriorityInterstitial();
		}
		else
		{
            if (p_rateContolled)
            {
                float minTimeDiffForInt = INTERSTITIALRATE * 10;
                float difference = Time.time - timeInterstitialShown;

                if (difference >= minTimeDiffForInt)
                {
                    ShowInterstitialWorker();
                    timeInterstitialShown = Time.time;         	
                }
            }
            else
            {
                ShowInterstitialWorker();
            }
		}
    }

    void ShowInterstitialWorker()
    {
        interstitialQueue[0].ShowInterstitialAd();
        interstitialQueue.RemoveAt(0);
        RequestTopPriorityInterstitial();
    }

	void RequestTopPriorityInterstitial()
	{
		if (interstitialImplementsPrioritized != null && interstitialImplementsPrioritized.Count > 0)
		{
			if (!interstitialImplementsPrioritized[0].IsInterstitialRequested() && !interstitialImplementsPrioritized[0].IsInterstitialLoaded())
			{
				interstitialImplementsPrioritized[0].RequestInterstitial();
			}
		}
	}

	void RequestTopPriorityVideoAd()
	{
		if (videoAdImplementsPrioritized != null && videoAdImplementsPrioritized.Count > 0)
		{
			if (!videoAdImplementsPrioritized[0].IsVideoAdRequested() && !videoAdImplementsPrioritized[0].IsVideoAdLoaded())
			{
				videoAdImplementsPrioritized[0].RequestVideoAd();
			}
		}
	}

	public void VideoAdLoadFailed(BasicAdNetwork p_adNetworkImplement)
	{
		int failedNetworkIndex = videoAdImplementsPrioritized.FindIndex(asd => asd.GetType() == p_adNetworkImplement.GetType());
		for (int i = failedNetworkIndex + 1; i < videoAdImplementsPrioritized.Count; i++)
		{
			if (!videoAdImplementsPrioritized[i].IsVideoAdRequested() && !videoAdImplementsPrioritized[i].IsVideoAdLoaded())
			{
				videoAdImplementsPrioritized[i].RequestVideoAd();
				break;
			}
		}
	}

	public void VideoAdLoadSuccess(BasicAdNetwork p_adNetworkImplement)
	{
        if (videoAdImplementsPrioritized.Find(asd => asd.GetType() == p_adNetworkImplement.GetType()) != null)
        {
            if (videoAdImplementsPrioritized[0].GetType() == p_adNetworkImplement.GetType())
                videoAdQueue.Insert(0, p_adNetworkImplement);
            else
                videoAdQueue.Add(p_adNetworkImplement);
        }
		
		RequestTopPriorityVideoAd();
	}

	public void VideoAdCompleted(BasicAdNetwork p_adNetworkImplement)
	{
		RequestTopPriorityVideoAd();
        if (rewardedVideoCompleteAction != null)
        {
            rewardedVideoCompleteAction.Invoke();
            rewardedVideoCompleteAction = null;
        }
	}

	public bool IsVideoAdAvailable()
    {
		if (this.videoAdQueue.Count > 0)
			return true;
		return false;
    }

    public delegate void InterstitialAdAction();
    InterstitialAdAction interstitialAdCompleteAction;

	public delegate void RewardedVideoAction();

	RewardedVideoAction rewardedVideoCompleteAction;
	RewardedVideoAction rewardedVideoNotAvailableAction;

	public void ShowVideoAd(RewardedVideoAction p_rewardedVideoCompleteAction, RewardedVideoAction p_rewardedVideoNotAvailableAction)
	{
		rewardedVideoCompleteAction = p_rewardedVideoCompleteAction;
		rewardedVideoNotAvailableAction = p_rewardedVideoNotAvailableAction;

		if (ENABLE_EDITOR_TESTING && (Application.platform == RuntimePlatform.OSXEditor || Application.platform == RuntimePlatform.WindowsEditor))
		{
			if (rewardedVideoCompleteAction != null)
				rewardedVideoCompleteAction.Invoke();
			return;
		}
		else
		{
			if (videoAdQueue.Count == 0)
			{
				RequestTopPriorityVideoAd();
				if (rewardedVideoNotAvailableAction != null)
					rewardedVideoNotAvailableAction.Invoke();
			}
			else
			{
				videoAdQueue[0].ShowVideoAd();
				
				videoAdQueue.RemoveAt(0);
				RequestTopPriorityVideoAd();
			}
		}
	}

	public void RateGame(bool p_rateControlled = false)
	{
		if (p_rateControlled)
		{
			RATECOUNTER++;
			if (RATECOUNTER == RATERATE)
			{
				RATECOUNTER = 0;
				if (!MRGame.Instance.rateClicked)
					ShowRateGameDialogue();
			}
		}
		else
			ShowRateGameDialogue();
	}

	void ShowRateGameDialogue()
	{
#if UNITY_IOS
		iOSReviewRequest.Request();
#endif
	}
}

public class BasicAdNetwork : MonoBehaviour
{
    public virtual void InitializeAdNetwork()
    {
        //Override
    }

    public virtual void RequestBanner()
	{
		//Override
	}

	public virtual void DestroyBanner()
	{
		//Override
	}

	public virtual void RequestInterstitial()
	{
		//Override
	}

	public virtual void RequestVideoAd()
	{
		//Override
	}

	public virtual void ShowInterstitialAd()
	{
		//override
	}

	public virtual void ShowVideoAd()
	{
		//override
	}

	public virtual void ShowForcedInterstitial()
	{
		//override
	}

	public virtual void ShowForcedVideoAd() 
	{
		//override
	}

	public virtual bool IsInterstitialRequested()
	{
		return false;
	}

	public virtual bool IsInterstitialLoaded()
	{
		return false;
	}

	public virtual bool IsVideoAdRequested()
	{
		return false;
	}

	public virtual bool IsVideoAdLoaded()
	{
		return false;
	}
}